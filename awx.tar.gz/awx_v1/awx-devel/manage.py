#!/usr/bin/env python

# Copyright (c) 2015 Ansible, Inc.
# All Rights Reserved.

if __name__ == '__main__':
    from awx import manage
    manage()
