export { default } from './CredentialChip';
