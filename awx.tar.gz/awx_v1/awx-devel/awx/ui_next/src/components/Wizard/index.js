export { default } from './Wizard';
