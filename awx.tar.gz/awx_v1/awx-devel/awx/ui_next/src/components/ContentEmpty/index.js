export { default } from './ContentEmpty';
