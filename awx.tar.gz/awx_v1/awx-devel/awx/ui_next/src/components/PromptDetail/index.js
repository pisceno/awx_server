export { default } from './PromptDetail';
