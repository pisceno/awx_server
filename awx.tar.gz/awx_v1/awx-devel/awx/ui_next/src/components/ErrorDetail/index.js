export { default } from './ErrorDetail';
