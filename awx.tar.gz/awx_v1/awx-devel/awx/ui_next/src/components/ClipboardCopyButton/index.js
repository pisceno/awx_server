export { default } from './ClipboardCopyButton';
