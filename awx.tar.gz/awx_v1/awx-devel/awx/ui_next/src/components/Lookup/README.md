# Lookup

required single select lookups should not include a close X on the tag... you would have to select something else to change it

optional single select lookups should include a close X to remove it on the spot
