export { default } from './FullPage';
