export const YAML_MODE = 'yaml';
export const JSON_MODE = 'javascript';
