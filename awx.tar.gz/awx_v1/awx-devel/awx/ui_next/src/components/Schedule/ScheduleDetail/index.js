export { default } from './ScheduleDetail';
