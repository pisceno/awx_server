import React, { Component } from 'react';
import { PageSection } from '@patternfly/react-core';

class SmartInventoryAdd extends Component {
  render() {
    return <PageSection>Coming soon :)</PageSection>;
  }
}

export default SmartInventoryAdd;
