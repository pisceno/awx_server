export { default } from './InventoryForm';
