export { default } from './InventoryGroupEdit';
