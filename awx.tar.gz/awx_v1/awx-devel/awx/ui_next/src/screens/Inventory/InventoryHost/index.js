export { default } from './InventoryHost';
