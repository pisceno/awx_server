export { default } from './InventoryEdit';
