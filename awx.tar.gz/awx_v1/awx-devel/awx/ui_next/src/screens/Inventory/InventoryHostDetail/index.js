export { default } from './InventoryHostDetail';
