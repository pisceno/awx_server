export { default } from './InventoryGroup';
