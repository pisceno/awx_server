export { default } from './InventoryGroupHosts';
