import React from 'react';

// eslint-disable-next-line import/prefer-default-export
export const WorkflowDispatchContext = React.createContext(null);
export const WorkflowStateContext = React.createContext(null);
