from collections import namedtuple

CredentialPlugin = namedtuple('CredentialPlugin', ['name', 'inputs', 'backend'])
