# Copyright (c) 2015 Ansible, Inc.
# All Rights Reserved.

# This file should only be present in a source checkout, and never in a release
# package, to allow us to determine whether we're running in a development or
# production mode.
